"use client";

import { useState } from "react";

export default function Home() {
  const [script, setScript] = useState("");
  const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [error, setError] = useState("");

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    setError("");
    setVideoUrl("");
    setFileName(file.name);

    if (!file.name.toLowerCase().endsWith(".txt")) {
      setError("இப்போது .txt script file மட்டும் upload செய்யலாம்.");
      return;
    }

    if (file.size > 1024 * 1024) {
      setError("Script file 1 MB-க்கு குறைவாக இருக்க வேண்டும்.");
      return;
    }

    const text = await file.text();
    setScript(text);
  }

  async function createVideo() {
    setError("");
    setVideoUrl("");

    if (!script.trim()) {
      setError("முதலில் script எழுதவும் அல்லது upload செய்யவும்.");
      return;
    }

    setLoading(true);
    setStatus("AI video job உருவாக்கப்படுகிறது...");

    try {
      const createRes = await fetch("/api/video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ script })
      });

      const createData = await createRes.json();

      if (!createRes.ok) {
        throw new Error(createData.error || "Video job உருவாக்க முடியவில்லை.");
      }

      const id = createData.id;
      setStatus("AI video உருவாகிறது... தயவுசெய்து காத்திருக்கவும்.");

      for (;;) {
        await new Promise((r) => setTimeout(r, 5000));

        const res = await fetch(`/api/video?id=${encodeURIComponent(id)}`);
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Status பெற முடியவில்லை.");
        }

        if (data.status === "succeeded") {
          setVideoUrl(data.videoUrl);
          setStatus("வீடியோ தயார்! 🎉");
          break;
        }

        if (data.status === "failed" || data.status === "canceled") {
          throw new Error("AI video generation தோல்வியடைந்தது.");
        }

        setStatus(`AI video உருவாகிறது... (${data.status})`);
      }
    } catch (err) {
      setError(err.message || "ஏதோ தவறு ஏற்பட்டது.");
      setStatus("");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page">
      <section className="hero">
        <div className="badge">தமிழ் AI VIDEO STUDIO</div>
        <h1>உங்கள் Script → AI Video</h1>
        <p>
          தமிழ் script-ஐ upload அல்லது paste செய்து, AI மூலம் video உருவாக்குங்கள்.
        </p>
      </section>

      <section className="card">
        <label className="label">1. உங்கள் Script</label>

        <label className="upload">
          <input type="file" accept=".txt,text/plain" onChange={handleFile} />
          <span>📄 Script .txt upload செய்ய கிளிக் செய்யவும்</span>
        </label>

        {fileName && <div className="filename">Uploaded: {fileName}</div>}

        <textarea
          value={script}
          onChange={(e) => setScript(e.target.value)}
          placeholder={"உதாரணம்:\nவணக்கம்! இன்று நாம் செயற்கை நுண்ணறிவு பற்றி பார்க்கலாம்..."}
          rows={12}
        />

        <div className="count">{script.length} characters</div>

        <button
          className="create"
          onClick={createVideo}
          disabled={loading}
        >
          {loading ? "⏳ உருவாக்கப்படுகிறது..." : "🎬 AI Video உருவாக்கு"}
        </button>

        {status && <div className="status">{status}</div>}
        {error && <div className="error">{error}</div>}
      </section>

      {videoUrl && (
        <section className="card result">
          <h2>உங்கள் AI Video</h2>
          <video src={videoUrl} controls playsInline />
          <a className="download" href={videoUrl} target="_blank" rel="noreferrer">
            ▶ வீடியோவை திறக்கவும்
          </a>
        </section>
      )}

      <footer>© 2026 Tamil AI Video Studio</footer>
    </main>
  );
}
